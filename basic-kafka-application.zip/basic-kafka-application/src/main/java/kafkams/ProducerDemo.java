package kafkams;

import java.util.Properties;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.serialization.StringSerializer;

public class ProducerDemo {

	public static void main(String[] args) {

		System.out.println("hello world");

		// create producer properties
		Properties properties = new Properties();
		properties.setProperty("bootstrap.servers", "localhost:9092");
		properties.setProperty("key.serializer", StringSerializer.class.getName()); // what type of value u are sending
																					// and how to convert into bytes
		properties.setProperty("value.serializer", StringSerializer.class.getName());

		// create producer
		KafkaProducer<String, String> producer = new KafkaProducer<String, String>(properties);

		// create a producer record
		// First String - topic name
		// Second String - String message to be produced
		ProducerRecord<String, String> record = new ProducerRecord<String, String>("first_topic",
				"hello world from Java");

		// send data - asynchronous method that runs in the background
		producer.send(record);

		// flush data and close producer
		producer.flush();
		producer.close();

	}

}
